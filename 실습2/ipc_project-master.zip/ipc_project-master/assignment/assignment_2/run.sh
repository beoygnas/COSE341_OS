gcc client.c -o client
gcc server.c -o server

./server &

./client &
